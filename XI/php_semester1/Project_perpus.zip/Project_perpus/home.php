<?php 
    include "header.php";
?>
<h2>Selamat datang <?=$_SESSION['nama_siswa']?> di website Perpus Online.</h2>
<?php
    include "footer.php";
?>
